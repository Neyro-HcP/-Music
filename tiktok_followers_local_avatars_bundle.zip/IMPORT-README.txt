IMPORT AVATARS INTO NEYRO-HCP/-MUSIC

This bundle contains:
- public/followers.json (79 TikTok usernames pointing to local avatar files)
- public/avatars/tiktok/ (77 unique JPEG avatars; repeated avatar URLs are reused)

To install:
1. Extract this ZIP.
2. In the GitHub repository Neyro-HcP/-Music, replace public/followers.json with the included file.
3. Upload all files from public/avatars/tiktok/ into the repository folder public/avatars/tiktok/.
4. Keep the existing Mafin618 card in index.html unchanged; it is not included in this follower list.

All avatar references in followers.json are local relative paths. The original expiring TikTok URLs are not used.
